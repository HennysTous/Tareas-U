
package ListaCircularEnlazada;

public class nodo {
    
    int numero;
    nodo siguiente;

}
